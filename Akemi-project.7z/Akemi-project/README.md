# Sales and Affiliate Management System

A modern, responsive web application for managing sales and affiliates with role-based access control and spreadsheet-style workflow.

## Features

### Authentication & Authorization
- Secure JWT-based authentication
- Two user roles: Admin and Affiliate
- Role-based access control enforced on backend
- Automatic session validation and suspension checks

### Admin Features
- Create, suspend, and delete affiliate accounts
- View all sales across all affiliates
- Edit and delete any sale entry
- Filter sales by affiliate, date range, event, or city
- Export sales data to CSV
- Protected admin account (cannot be deleted or suspended)

### Affiliate Features
- Create new sales entries
- View only their own sales
- Automatic commission calculation
- Read-only view of submitted entries
- Dashboard with sales statistics

### Sales Management
- Spreadsheet-style table interface
- Duplicate prevention (phone + event combination)
- Server-side commission calculation:
  - Commission = Sell Price - Original Price
  - If prices are equal: $500 commission
  - Maximum commission: $500
  - Minimum commission: $0
- Real-time validation and error handling

### Technical Features
- PostgreSQL database with foreign keys and constraints
- Responsive mobile-first design
- Clean, professional UI
- Fast performance with indexed queries
- Secure password hashing with bcrypt
- CORS-enabled API

## Technology Stack

### Backend
- Node.js + Express
- PostgreSQL
- JWT for authentication
- bcrypt for password hashing

### Frontend
- React 18
- React Router v6
- Axios for API calls
- CSS3 with responsive design

## Installation

### Prerequisites
- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

### Step 1: Database Setup

1. Create a PostgreSQL database:
```bash
createdb sales_affiliate_db
```

2. Run the schema:
```bash
psql sales_affiliate_db < server/database/schema.sql
```

This creates the tables and inserts a default admin user:
- Email: `admin@example.com`
- Password: `admin123`

### Step 2: Backend Setup

1. Install backend dependencies:
```bash
npm install
```

2. Create a `.env` file in the root directory:
```env
PORT=5000
DATABASE_URL=postgresql://username:password@localhost:5432/sales_affiliate_db
JWT_SECRET=your-secret-key-change-this-in-production
NODE_ENV=development
```

Replace `username` and `password` with your PostgreSQL credentials.

### Step 3: Frontend Setup

1. Install frontend dependencies:
```bash
cd client
npm install
```

### Step 4: Running the Application

#### Development Mode (both servers)
From the root directory:
```bash
npm run dev
```

This starts:
- Backend server on http://localhost:5000
- Frontend server on http://localhost:3000

#### Production Mode

1. Build the frontend:
```bash
npm run build
```

2. Start the backend:
```bash
npm start
```

## Usage

### Login
1. Navigate to http://localhost:3000
2. Use the default admin credentials or an affiliate account

### Admin Dashboard
- **Sales Management Tab**: View, filter, edit, and delete all sales
- **User Management Tab**: Create, suspend, activate, and delete affiliate users
- Use filters to search by date range, event, city, or affiliate
- Click "Export to CSV" to download sales data

### Affiliate Dashboard
- View personal sales statistics
- Click "Add New Sale" to create a new entry
- View all submitted sales in spreadsheet format

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `GET /api/auth/verify` - Verify token

### Users (Admin Only)
- `GET /api/users` - Get all users
- `GET /api/users/:id` - Get single user
- `POST /api/users` - Create affiliate user
- `PATCH /api/users/:id/status` - Update user status
- `DELETE /api/users/:id` - Delete user

### Sales
- `GET /api/sales` - Get sales (filtered by role)
- `GET /api/sales/:id` - Get single sale
- `POST /api/sales` - Create sale
- `PUT /api/sales/:id` - Update sale (admin only)
- `DELETE /api/sales/:id` - Delete sale (admin only)

## Security Features

1. **Password Security**: Passwords hashed with bcrypt (10 rounds)
2. **JWT Tokens**: 24-hour expiration with secure secret
3. **Role Validation**: All permissions checked on backend
4. **Suspended Account Check**: Verified on every request
5. **SQL Injection Protection**: Parameterized queries
6. **Foreign Key Constraints**: Data integrity maintained
7. **Unique Constraints**: Duplicate prevention at database level

## Database Schema

### Users Table
- `id` (Primary Key)
- `email` (Unique)
- `password_hash`
- `role` (admin | affiliate)
- `status` (active | suspended)
- `created_at`

### Sales Table
- `id` (Primary Key)
- `date`
- `affiliate_id` (Foreign Key → users.id)
- `client_full_name`
- `event`
- `phone_number`
- `city_or_online`
- `original_price`
- `sell_price`
- `commission` (Auto-calculated)
- `remarks`
- `created_at`
- `updated_at`
- Unique constraint: (phone_number, event)

## Commission Calculation Logic

The commission is calculated automatically on the server:

```javascript
if (original_price === sell_price) {
  commission = 500;
} else {
  difference = sell_price - original_price;
  if (difference <= 0) {
    commission = 0;
  } else if (difference > 500) {
    commission = 500;
  } else {
    commission = difference;
  }
}
```

## Business Rules

1. Only one admin account exists
2. Admin account cannot be deleted or suspended from UI
3. Affiliates can only create and view their own sales
4. Sales entries cannot be edited or deleted by affiliates
5. Duplicate entries (same phone + event) are blocked
6. All prices must be non-negative
7. Commission is always between $0 and $500
8. Suspended users are blocked immediately on login
9. All access control is enforced on backend

## Responsive Design

The application is fully responsive and optimized for:
- Desktop (1400px+)
- Tablet (768px - 1399px)
- Mobile (< 768px)

## Troubleshooting

### Database Connection Issues
- Verify PostgreSQL is running
- Check DATABASE_URL in .env file
- Ensure database exists and schema is applied

### Port Conflicts
- Backend default: 5000
- Frontend default: 3000
- Change PORT in .env if needed

### Token Issues
- Clear browser localStorage
- Check JWT_SECRET is set in .env
- Verify token expiration (24 hours)

## License

MIT

## Support

For issues or questions, please check the documentation or contact support.
