import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import SalesTable from '../components/SalesTable';
import UserManagement from '../components/UserManagement';
import api from '../api/axios';
import './Dashboard.css';

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('sales');
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    affiliate_id: '',
    date_from: '',
    date_to: '',
    event: '',
    city: ''
  });

  useEffect(() => {
    if (activeTab === 'sales') {
      fetchSales();
    }
  }, [activeTab, filters]);

  const fetchSales = async () => {
    try {
      setLoading(true);
      setError('');

      const params = {};
      if (filters.affiliate_id) params.affiliate_id = filters.affiliate_id;
      if (filters.date_from) params.date_from = filters.date_from;
      if (filters.date_to) params.date_to = filters.date_to;
      if (filters.event) params.event = filters.event;
      if (filters.city) params.city = filters.city;

      const response = await api.get('/sales', { params });
      setSales(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch sales');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const clearFilters = () => {
    setFilters({
      affiliate_id: '',
      date_from: '',
      date_to: '',
      event: '',
      city: ''
    });
  };

  const exportToCSV = () => {
    if (sales.length === 0) {
      alert('No data to export');
      return;
    }

    const headers = [
      'ID', 'Date', 'Affiliate Email', 'Client Name', 'Event',
      'Phone', 'City/Online', 'Original Price', 'Sell Price', 'Commission', 'Remarks'
    ];

    const rows = sales.map(sale => [
      sale.id,
      sale.date,
      sale.affiliate_email,
      sale.client_full_name,
      sale.event,
      sale.phone_number,
      sale.city_or_online,
      sale.original_price,
      sale.sell_price,
      sale.commission,
      sale.remarks || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales_export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="dashboard">
      <Navbar />

      <div className="container">
        <div className="dashboard-header">
          <h1>Admin Dashboard</h1>
        </div>

        <div className="tabs">
          <button
            className={`tab ${activeTab === 'sales' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('sales')}
          >
            Sales Management
          </button>
          <button
            className={`tab ${activeTab === 'users' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            User Management
          </button>
        </div>

        {activeTab === 'sales' && (
          <>
            <div className="card">
              <div className="card-header">Filters</div>
              <div className="filters-grid">
                <div className="form-group">
                  <label className="form-label">Date From</label>
                  <input
                    type="date"
                    className="input"
                    value={filters.date_from}
                    onChange={(e) => handleFilterChange('date_from', e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Date To</label>
                  <input
                    type="date"
                    className="input"
                    value={filters.date_to}
                    onChange={(e) => handleFilterChange('date_to', e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Event</label>
                  <input
                    type="text"
                    className="input"
                    value={filters.event}
                    onChange={(e) => handleFilterChange('event', e.target.value)}
                    placeholder="Search by event"
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">City</label>
                  <input
                    type="text"
                    className="input"
                    value={filters.city}
                    onChange={(e) => handleFilterChange('city', e.target.value)}
                    placeholder="Search by city"
                  />
                </div>
              </div>
              <div className="filters-actions">
                <button onClick={clearFilters} className="btn btn-secondary btn-sm">
                  Clear Filters
                </button>
                <button onClick={exportToCSV} className="btn btn-success btn-sm">
                  Export to CSV
                </button>
              </div>
            </div>

            {error && <div className="alert alert-error">{error}</div>}

            <SalesTable
              sales={sales}
              loading={loading}
              onRefresh={fetchSales}
              isAdmin={true}
            />
          </>
        )}

        {activeTab === 'users' && <UserManagement />}
      </div>
    </div>
  );
}

export default AdminDashboard;
