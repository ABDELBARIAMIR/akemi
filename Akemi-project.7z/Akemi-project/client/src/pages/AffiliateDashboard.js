import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import SalesTable from '../components/SalesTable';
import SaleForm from '../components/SaleForm';
import api from '../api/axios';
import './Dashboard.css';

function AffiliateDashboard() {
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchSales();
  }, []);

  const fetchSales = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await api.get('/sales');
      setSales(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch sales');
    } finally {
      setLoading(false);
    }
  };

  const handleSaleCreated = () => {
    setShowForm(false);
    fetchSales();
  };

  const totalCommission = sales.reduce((sum, sale) => sum + parseFloat(sale.commission), 0);

  return (
    <div className="dashboard">
      <Navbar />

      <div className="container">
        <div className="dashboard-header">
          <h1>Affiliate Dashboard</h1>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-label">Total Sales</div>
            <div className="stat-value">{sales.length}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Total Commission</div>
            <div className="stat-value">${totalCommission.toFixed(2)}</div>
          </div>
        </div>

        <div className="card">
          <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>My Sales</span>
            <button onClick={() => setShowForm(true)} className="btn btn-primary btn-sm">
              Add New Sale
            </button>
          </div>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <SalesTable
          sales={sales}
          loading={loading}
          onRefresh={fetchSales}
          isAdmin={false}
        />

        {showForm && (
          <SaleForm
            onClose={() => setShowForm(false)}
            onSuccess={handleSaleCreated}
          />
        )}
      </div>
    </div>
  );
}

export default AffiliateDashboard;
