import React, { useState } from 'react';
import SaleForm from './SaleForm';
import api from '../api/axios';
import './SalesTable.css';

function SalesTable({ sales, loading, onRefresh, isAdmin }) {
  const [editingSale, setEditingSale] = useState(null);

  const handleEdit = (sale) => {
    setEditingSale(sale);
  };

  const handleDelete = async (saleId) => {
    if (!window.confirm('Are you sure you want to delete this sale? This action cannot be undone.')) {
      return;
    }

    try {
      await api.delete(`/sales/${saleId}`);
      onRefresh();
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to delete sale');
    }
  };

  const handleEditSuccess = () => {
    setEditingSale(null);
    onRefresh();
  };

  if (loading) {
    return <div className="spinner"></div>;
  }

  if (sales.length === 0) {
    return (
      <div className="card">
        <div className="empty-state">
          <p>No sales records found</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              {isAdmin && <th>Affiliate</th>}
              <th>Client Name</th>
              <th>Event</th>
              <th>Phone</th>
              <th>City/Online</th>
              <th>Original Price</th>
              <th>Sell Price</th>
              <th>Commission</th>
              <th>Remarks</th>
              {isAdmin && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {sales.map(sale => (
              <tr key={sale.id}>
                <td>{sale.id}</td>
                <td>{new Date(sale.date).toLocaleDateString()}</td>
                {isAdmin && <td>{sale.affiliate_email}</td>}
                <td>{sale.client_full_name}</td>
                <td>{sale.event}</td>
                <td>{sale.phone_number}</td>
                <td>{sale.city_or_online}</td>
                <td>${parseFloat(sale.original_price).toFixed(2)}</td>
                <td>${parseFloat(sale.sell_price).toFixed(2)}</td>
                <td className="commission-cell">
                  ${parseFloat(sale.commission).toFixed(2)}
                </td>
                <td className="remarks-cell">{sale.remarks || '-'}</td>
                {isAdmin && (
                  <td>
                    <div className="table-actions">
                      <button
                        onClick={() => handleEdit(sale)}
                        className="btn btn-primary btn-sm"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(sale.id)}
                        className="btn btn-danger btn-sm"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editingSale && (
        <SaleForm
          sale={editingSale}
          onClose={() => setEditingSale(null)}
          onSuccess={handleEditSuccess}
        />
      )}
    </>
  );
}

export default SalesTable;
