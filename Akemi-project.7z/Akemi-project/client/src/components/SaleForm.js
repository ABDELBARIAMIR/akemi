import React, { useState } from 'react';
import api from '../api/axios';

function SaleForm({ onClose, onSuccess, sale = null }) {
  const isEdit = !!sale;

  const [formData, setFormData] = useState({
    date: sale?.date || new Date().toISOString().split('T')[0],
    client_full_name: sale?.client_full_name || '',
    event: sale?.event || '',
    phone_number: sale?.phone_number || '',
    city_or_online: sale?.city_or_online || '',
    original_price: sale?.original_price || '',
    sell_price: sale?.sell_price || '',
    remarks: sale?.remarks || ''
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isEdit) {
        await api.put(`/sales/${sale.id}`, formData);
      } else {
        await api.post('/sales', formData);
      }
      onSuccess();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to save sale');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">{isEdit ? 'Edit Sale' : 'Add New Sale'}</h3>
          <button className="modal-close" onClick={onClose}>
            &times;
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && (
              <div className="alert alert-error">{error}</div>
            )}

            <div className="form-group">
              <label className="form-label">Date *</label>
              <input
                type="date"
                className="input"
                value={formData.date}
                onChange={(e) => handleChange('date', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Client Full Name *</label>
              <input
                type="text"
                className="input"
                value={formData.client_full_name}
                onChange={(e) => handleChange('client_full_name', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Event *</label>
              <input
                type="text"
                className="input"
                value={formData.event}
                onChange={(e) => handleChange('event', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Phone Number *</label>
              <input
                type="text"
                className="input"
                value={formData.phone_number}
                onChange={(e) => handleChange('phone_number', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">City or Online *</label>
              <input
                type="text"
                className="input"
                value={formData.city_or_online}
                onChange={(e) => handleChange('city_or_online', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Original Price *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="input"
                value={formData.original_price}
                onChange={(e) => handleChange('original_price', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Sell Price *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="input"
                value={formData.sell_price}
                onChange={(e) => handleChange('sell_price', e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Remarks</label>
              <textarea
                className="input"
                rows="3"
                value={formData.remarks}
                onChange={(e) => handleChange('remarks', e.target.value)}
              />
            </div>

            {!isEdit && (
              <div className="alert alert-info">
                <strong>Commission Calculation:</strong> Automatically calculated as (Sell Price - Original Price).
                If prices are equal, commission is $500. Maximum commission is $500.
              </div>
            )}
          </div>

          <div className="modal-footer">
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? 'Saving...' : isEdit ? 'Update Sale' : 'Create Sale'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default SaleForm;
