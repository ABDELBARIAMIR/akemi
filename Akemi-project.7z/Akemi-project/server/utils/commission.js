/**
 * Calculate commission based on business rules:
 * - Commission = sell_price - original_price
 * - If original_price === sell_price, commission = 500
 * - If (sell_price - original_price) > 500, commission = 500
 * - If result <= 0, commission = 0
 * - Commission cannot exceed 500
 */
function calculateCommission(originalPrice, sellPrice) {
  const originalPriceNum = parseFloat(originalPrice);
  const sellPriceNum = parseFloat(sellPrice);

  // Validation
  if (isNaN(originalPriceNum) || isNaN(sellPriceNum)) {
    throw new Error('Invalid price values');
  }

  if (originalPriceNum < 0 || sellPriceNum < 0) {
    throw new Error('Prices cannot be negative');
  }

  // If prices are equal, commission is 500
  if (originalPriceNum === sellPriceNum) {
    return 500;
  }

  // Calculate difference
  const difference = sellPriceNum - originalPriceNum;

  // If difference is negative or zero, commission is 0
  if (difference <= 0) {
    return 0;
  }

  // If difference exceeds 500, cap at 500
  if (difference > 500) {
    return 500;
  }

  // Return the difference as commission
  return Math.round(difference * 100) / 100; // Round to 2 decimal places
}

module.exports = {
  calculateCommission
};
