const express = require('express');
const db = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { calculateCommission } = require('../utils/commission');

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get sales - role-based access control
router.get('/', async (req, res) => {
  try {
    const { affiliate_id, date_from, date_to, event, city } = req.query;

    let query = `
      SELECT s.*, u.email as affiliate_email
      FROM sales s
      JOIN users u ON s.affiliate_id = u.id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    // Affiliates can only see their own sales
    if (req.user.role === 'affiliate') {
      paramCount++;
      query += ` AND s.affiliate_id = $${paramCount}`;
      params.push(req.user.id);
    } else if (req.user.role === 'admin') {
      // Admin can filter by affiliate_id
      if (affiliate_id) {
        paramCount++;
        query += ` AND s.affiliate_id = $${paramCount}`;
        params.push(affiliate_id);
      }
    }

    // Date filtering (available for admin)
    if (date_from && req.user.role === 'admin') {
      paramCount++;
      query += ` AND s.date >= $${paramCount}`;
      params.push(date_from);
    }

    if (date_to && req.user.role === 'admin') {
      paramCount++;
      query += ` AND s.date <= $${paramCount}`;
      params.push(date_to);
    }

    // Event filtering (available for admin)
    if (event && req.user.role === 'admin') {
      paramCount++;
      query += ` AND s.event ILIKE $${paramCount}`;
      params.push(`%${event}%`);
    }

    // City filtering (available for admin)
    if (city && req.user.role === 'admin') {
      paramCount++;
      query += ` AND s.city_or_online ILIKE $${paramCount}`;
      params.push(`%${city}%`);
    }

    query += ' ORDER BY s.date DESC, s.created_at DESC';

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get sales error:', error);
    res.status(500).json({ error: 'Failed to fetch sales' });
  }
});

// Get single sale
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      'SELECT s.*, u.email as affiliate_email FROM sales s JOIN users u ON s.affiliate_id = u.id WHERE s.id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Sale not found' });
    }

    const sale = result.rows[0];

    // Affiliates can only view their own sales
    if (req.user.role === 'affiliate' && sale.affiliate_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(sale);
  } catch (error) {
    console.error('Get sale error:', error);
    res.status(500).json({ error: 'Failed to fetch sale' });
  }
});

// Create sale - affiliates can create, admin can also create
router.post('/', async (req, res) => {
  try {
    const {
      date,
      client_full_name,
      event,
      phone_number,
      city_or_online,
      original_price,
      sell_price,
      remarks
    } = req.body;

    // Validation
    if (!date || !client_full_name || !event || !phone_number || !city_or_online) {
      return res.status(400).json({ error: 'All required fields must be provided' });
    }

    if (original_price === undefined || original_price === null || sell_price === undefined || sell_price === null) {
      return res.status(400).json({ error: 'Original price and sell price are required' });
    }

    if (parseFloat(original_price) < 0 || parseFloat(sell_price) < 0) {
      return res.status(400).json({ error: 'Prices cannot be negative' });
    }

    // Check for duplicate (phone_number + event)
    const duplicateCheck = await db.query(
      'SELECT id FROM sales WHERE phone_number = $1 AND event = $2',
      [phone_number.trim(), event.trim()]
    );

    if (duplicateCheck.rows.length > 0) {
      return res.status(409).json({
        error: 'Duplicate entry detected. A sale with this phone number and event already exists.'
      });
    }

    // Calculate commission
    const commission = calculateCommission(original_price, sell_price);

    // Use current user's ID as affiliate_id
    const affiliateId = req.user.id;

    // Insert sale
    const result = await db.query(
      `INSERT INTO sales
        (date, affiliate_id, client_full_name, event, phone_number, city_or_online, original_price, sell_price, commission, remarks)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        date,
        affiliateId,
        client_full_name.trim(),
        event.trim(),
        phone_number.trim(),
        city_or_online.trim(),
        parseFloat(original_price),
        parseFloat(sell_price),
        commission,
        remarks ? remarks.trim() : null
      ]
    );

    // Get affiliate email
    const userResult = await db.query('SELECT email FROM users WHERE id = $1', [affiliateId]);
    const saleWithEmail = {
      ...result.rows[0],
      affiliate_email: userResult.rows[0].email
    };

    res.status(201).json(saleWithEmail);
  } catch (error) {
    console.error('Create sale error:', error);
    if (error.code === '23505') { // PostgreSQL unique constraint violation
      return res.status(409).json({
        error: 'Duplicate entry detected. A sale with this phone number and event already exists.'
      });
    }
    res.status(500).json({ error: 'Failed to create sale' });
  }
});

// Update sale - admin only
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const {
      date,
      client_full_name,
      event,
      phone_number,
      city_or_online,
      original_price,
      sell_price,
      remarks
    } = req.body;

    // Check if sale exists
    const existingResult = await db.query('SELECT id FROM sales WHERE id = $1', [id]);
    if (existingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Sale not found' });
    }

    // Validation
    if (!date || !client_full_name || !event || !phone_number || !city_or_online) {
      return res.status(400).json({ error: 'All required fields must be provided' });
    }

    if (original_price === undefined || original_price === null || sell_price === undefined || sell_price === null) {
      return res.status(400).json({ error: 'Original price and sell price are required' });
    }

    if (parseFloat(original_price) < 0 || parseFloat(sell_price) < 0) {
      return res.status(400).json({ error: 'Prices cannot be negative' });
    }

    // Check for duplicate (excluding current record)
    const duplicateCheck = await db.query(
      'SELECT id FROM sales WHERE phone_number = $1 AND event = $2 AND id != $3',
      [phone_number.trim(), event.trim(), id]
    );

    if (duplicateCheck.rows.length > 0) {
      return res.status(409).json({
        error: 'Duplicate entry detected. A sale with this phone number and event already exists.'
      });
    }

    // Recalculate commission
    const commission = calculateCommission(original_price, sell_price);

    // Update sale
    const result = await db.query(
      `UPDATE sales
       SET date = $1, client_full_name = $2, event = $3, phone_number = $4,
           city_or_online = $5, original_price = $6, sell_price = $7,
           commission = $8, remarks = $9, updated_at = CURRENT_TIMESTAMP
       WHERE id = $10
       RETURNING *`,
      [
        date,
        client_full_name.trim(),
        event.trim(),
        phone_number.trim(),
        city_or_online.trim(),
        parseFloat(original_price),
        parseFloat(sell_price),
        commission,
        remarks ? remarks.trim() : null,
        id
      ]
    );

    // Get affiliate email
    const userResult = await db.query(
      'SELECT email FROM users WHERE id = $1',
      [result.rows[0].affiliate_id]
    );
    const saleWithEmail = {
      ...result.rows[0],
      affiliate_email: userResult.rows[0].email
    };

    res.json(saleWithEmail);
  } catch (error) {
    console.error('Update sale error:', error);
    if (error.code === '23505') {
      return res.status(409).json({
        error: 'Duplicate entry detected. A sale with this phone number and event already exists.'
      });
    }
    res.status(500).json({ error: 'Failed to update sale' });
  }
});

// Delete sale - admin only
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query('DELETE FROM sales WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Sale not found' });
    }

    res.json({ message: 'Sale deleted successfully' });
  } catch (error) {
    console.error('Delete sale error:', error);
    res.status(500).json({ error: 'Failed to delete sale' });
  }
});

module.exports = router;
