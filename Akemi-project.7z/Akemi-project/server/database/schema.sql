-- Sales and Affiliate Management System Database Schema

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS sales CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'affiliate')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sales table
CREATE TABLE sales (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    affiliate_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_full_name VARCHAR(255) NOT NULL,
    event VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    city_or_online VARCHAR(255) NOT NULL,
    original_price DECIMAL(10, 2) NOT NULL CHECK (original_price >= 0),
    sell_price DECIMAL(10, 2) NOT NULL CHECK (sell_price >= 0),
    commission DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (commission >= 0 AND commission <= 500),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_phone_event UNIQUE (phone_number, event)
);

-- Create indexes for better performance
CREATE INDEX idx_sales_affiliate_id ON sales(affiliate_id);
CREATE INDEX idx_sales_date ON sales(date);
CREATE INDEX idx_sales_event ON sales(event);
CREATE INDEX idx_sales_city_or_online ON sales(city_or_online);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Insert default admin user (password: admin123)
-- Password hash generated with bcrypt for 'admin123'
INSERT INTO users (email, password_hash, role, status)
VALUES ('admin@example.com', '$2b$10$rZ5YhkqGZxmVXZJCkqYGV.xJXHfXDnJHO3LQ8PXxYF1vKqKJYqKJC', 'admin', 'active');
